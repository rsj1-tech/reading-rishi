import { Book } from '../types';

export const BOOKS_DATABASE: Book[] = [
  {
    id: 'alice_wonderland',
    title: "Alice's Adventures in Wonderland",
    author: "Lewis Carroll",
    year: "1865",
    genre: ["Fantasy", "Literary", "Classics"],
    description: "Follow Alice as she falls down a rabbit hole into a whimsical, illogical world filled with memorable creatures like the Cheshire Cat, the Mad Hatter, and the Queen of Hearts.",
    coverEmoji: "🐇",
    coverBg: "linear-gradient(135deg, #243B55 0%, #141E30 100%)",
    rating: 4.8,
    readersCount: 42350,
    estimatedReadTime: "2 hours",
    chapters: [
      {
        id: 'alice_ch1',
        number: 1,
        title: "Down the Rabbit-Hole",
        paragraphs: [
          "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,' thought Alice 'without pictures or conversations?'",
          "So she was considering in her own mind (as well as she could, for the hot day made her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be worth the trouble of getting up and picking the daisies, when suddenly a White Rabbit with pink eyes ran close by her.",
          "There was nothing so very remarkable in that; nor did Alice think it so very much out of the way to hear the Rabbit say to itself, 'Oh dear! Oh dear! I shall be late!' (when she thought it over afterwards, it occurred to her that she ought to have wondered at this, but at the time it all seemed quite natural); but when the Rabbit actually took a watch out of its waistcoat-pocket, and looked at it, and then hurried on, Alice started to her feet, for it flashed across her mind that she had never before seen a rabbit with either a waistcoat-pocket, or a watch to take out of it, and burning with curiosity, she ran across the field after it, and fortunately was just in time to see it pop down a large rabbit-hole under the hedge.",
          "In another moment down went Alice after it, never once considering how in the world she was to get out again.",
          "The rabbit-hole went straight on like a tunnel for some way, and then dipped suddenly down, so suddenly that Alice had not a moment to think about stopping herself before she found herself falling down a very deep well.",
          "Either the well was very deep, or she fell very slowly, for she had plenty of time as she went down to look about her and to wonder what was going to happen next. First, she tried to look down and make out what she was coming to, but it was too dark to see anything; then she looked at the sides of the well, and noticed that they were filled with cupboards and book-shelves; here and there she saw maps and pictures hung upon pegs. She took down a jar from one of the shelves as she passed; it was labelled 'ORANGE MARMALADE', but to her great disappointment it was empty: she did not like to drop the jar for fear of killing somebody, so managed to put it into one of the cupboards as she fell past it.",
          "'Well!' thought Alice to herself, 'after such a fall as this, I shall think nothing of tumbling down stairs! How brave they'll all think me at home! Why, I wouldn't say anything about it, even if I fell off the top of the house!' (Which was very likely true.)",
          "Down, down, down. Would the fall never come to an end? 'I wonder how many miles I've fallen by this time?' she said aloud. 'I must be getting somewhere near the centre of the earth. Let me see: that would be four thousand miles down, I think—' (for, you see, Alice had learnt several things of this sort in her lessons in the schoolroom, and though this was not a very good opportunity for showing off her knowledge, as there was no one to listen to her, still it was good practice to say it over) '—yes, that's about the right distance—but then I wonder what Latitude or Longitude I've got to?' (Alice had no idea what Latitude was, or Longitude either, but thought they were nice grand words to say.)",
          "Presently she began again. 'I wonder if I shall fall right through the earth! How funny it'll seem to come out among the people that walk with their heads downward! The Antipathies, I think—' (she was rather glad there was no one listening, this time, as it didn't sound at all the right word) '—but I shall have to ask them what the name of the country is, you know. Please, Ma'am, is this New Zealand or Australia?' (and she tried to curtsey as she spoke—fancy curtseying as you're falling through the air! Do you think you could manage it?) 'And what an ignorant little girl she'll think me for asking! No, it'll never do to ask: perhaps I shall see it written up somewhere.'"
        ]
      },
      {
        id: 'alice_ch2',
        number: 2,
        title: "The Pool of Tears",
        paragraphs: [
          "'Curiouser and curiouser!' cried Alice (she was so much surprised, that for the moment she quite forgot how to speak good English); 'now I'm opening out like the largest telescope that ever was! Good-bye, feet!' (for when she looked down at her feet, they seemed to be almost out of sight, they were getting so far off). 'Oh, my poor little feet, I wonder who will put on your shoes and stockings for you now, dears? I'm sure I shan't be able! I shall be a great deal too far off to trouble myself about you: you must manage the best way you can;—but I must be kind to them,' thought Alice, 'or perhaps they won't walk the way I want to go! Let me see: I'll give them a new pair of boots every Christmas.'",
          "And she went on planning to herself how she would manage it. 'They must go by the carrier,' she thought; 'and how funny it'll seem, sending presents to one's own feet! And how odd the directions will look!'",
          "Just then her head struck against the roof of the hall: in fact she was now more than nine feet high, and she at once took up the little golden key and hurried off to the garden door.",
          "Poor Alice! It was as much as she could do, lying down on one side, to look through into the garden with one eye; but to get through was more hopeless than ever: she sat down and began to cry again.",
          "She went on shedding gallons of tears, until there was a large pool all round her, about four inches deep and reaching half over the hall.",
          "After a time she heard a little pattering of feet in the distance, and she hastily dried her eyes to see what was coming. It was the White Rabbit returning, splendidly dressed, with a pair of white kid gloves in one hand and a large fan in the other: he came trotting along in a great hurry, muttering to himself as he came, 'Oh! the Duchess, the Duchess! Oh! won't she be savage if I've kept her waiting!'",
          "Alice felt so desperate that she was ready to ask help of any one; so, when the Rabbit came near her, she began, in a low, timid voice, 'If you please, sir—' The Rabbit started violently, dropped the white kid gloves and the fan, and skurried away into the darkness as hard as he could go."
        ]
      }
    ]
  },
  {
    id: 'metamorphosis',
    title: "The Metamorphosis",
    author: "Franz Kafka",
    year: "1915",
    genre: ["Classics", "Philosophy", "Absurdist"],
    description: "One morning, Gregor Samsa wakes up to find himself transformed into a monstrous verminous insect. His absurd new form challenges his identity and relationships with his family.",
    coverEmoji: "🪲",
    coverBg: "linear-gradient(135deg, #3E2723 0%, #1A0F0A 100%)",
    rating: 4.7,
    readersCount: 35120,
    estimatedReadTime: "1.5 hours",
    chapters: [
      {
        id: 'meta_ch1',
        number: 1,
        title: "I. The Awakening",
        paragraphs: [
          "One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin. He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by arches into stiff sections.",
          "The bedding was hardly able to cover it and seemed ready to slide off any moment. His many legs, pitifully thin compared with the size of the rest of him, waved helplessly before his eyes.",
          "'What's happened to me?' he thought. It was no dream. His room, a proper human room although a little too small, lay peacefully between its four familiar walls. A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower arm towards the viewer.",
          "Gregor then turned to look out the window at the dull weather. Drops of rain could be heard hitting the pane, which made him feel quite sad. 'How about if I sleep a little bit longer and forget all this nonsense', he thought, but that was something he was unable to do because he was used to sleeping on his right, and in his present state he couldn't get into that position. However hard he threw himself onto his right, he always rolled back to where he was.",
          "He must have tried it a hundred times, shut his eyes so that he wouldn't have to look at the floundering legs, and only stopped when he began to feel a mild, dull pain there that he had never felt before.",
          "'Oh, God', he thought, 'what a strenuous career it is that I've chosen! Travelling day in and day out. Doing business like this takes much more effort than doing your own business at home, and on top of that there's the curse of travelling, worries about making train connections, bad and irregular food, contact with different people all the time so that you can never establish any warm, lasting friendship or affection. Let the devil take it all!'"
        ]
      },
      {
        id: 'meta_ch2',
        number: 2,
        title: "II. Food and Solitude",
        paragraphs: [
          "It was not until the evening that Gregor woke from his deep, sleep-like trance. He would probably have woken up not much later anyway even without any disturbance, as he felt sufficiently rested and slept off, but it seemed to him that he heard hurried steps and the sound of the door leading to the front room being shut carefully.",
          "The light from the electric street lamps shone pale here and there on the ceiling and on the upper parts of the furniture, but down where Gregor was it was dark. Feeling his way awkwardly with his antennae, which he only now began to learn to appreciate, he crawled slowly towards the door to see what had happened there.",
          "His left side seemed to be one single, long, unpleasantly tight scar, and he had to limp on his two rows of legs. One of the legs, besides, had been badly injured during the course of the morning's events - it was nearly a miracle that only one had been hurt - and it dragged along lifelessly.",
          "It was only beside the door that he realized what had really drawn him there; it was the smell of something to eat. A bowl of sweet milk stood there, in which floated little pieces of white bread. He almost laughed with joy, as he was even hungrier than he had been in the morning, and he immediately dipped his head into the milk, almost up over his eyes.",
          "But he soon drew it back again in disappointment; not only did he find it difficult to eat because of his tender left side - and he could only eat if his whole panting body worked in unison - but he did not like the milk at all, even though it had always been his favourite drink and his sister had certainly put it there for that reason. He turned away from the bowl with almost a feeling of aversion and crawled back into the middle of the room."
        ]
      }
    ]
  },
  {
    id: 'time_machine',
    title: "The Time Machine",
    author: "H.G. Wells",
    year: "1895",
    genre: ["Sci-Fi", "Classics", "Adventure"],
    description: "A Victorian scientist asserts that time is simply a fourth dimension, constructing a machine capable of travelling through history. He journeys to the year 802,701 AD, finding a world populated by two species: the peaceful Eloi and the monstrous Morlocks.",
    coverEmoji: "⏳",
    coverBg: "linear-gradient(135deg, #11998e 0%, #38ef7d 100%)",
    rating: 4.6,
    readersCount: 28940,
    estimatedReadTime: "1.2 hours",
    chapters: [
      {
        id: 'time_ch1',
        number: 1,
        title: "I. The Fourth Dimension",
        paragraphs: [
          "The Time Traveller (for so it will be convenient to speak of him) was expounding a recondite matter to us. His grey eyes shone and twinkled, and his usually pale face was flushed and animated. The fire burned brightly, and the soft radiance of the incandescent lights in the lilies of silver caught the bubbles that flashed and passed in our glasses.",
          "Our chairs, being his patents, embraced and caressed us rather than submitted to be sat upon, and there was that luxurious after-dinner atmosphere when thought runs gracefully free of the trammels of precision. And he put it to us in this way—pointing his forefinger, while we sat and watched him:",
          "'You must follow me carefully. I shall have to controvert one or two ideas that are almost universally accepted. The geometry, for instance, they taught you at school is founded on a misconception.'",
          "'Is not that rather a large thing to expect us to begin upon?' said Filby, an argumentative person with red hair.",
          "'I do not mean to ask you to accept anything without reasonable ground for it. You will soon admit as much as I need from you. You know of course that a mathematical line, a line of thickness nil, has no real existence. They taught you that? Neither has a mathematical plane. These things are mere abstractions.'",
          "'That is all right,' said the Psychologist.",
          "'Nor, having only length, breadth, and thickness, can a cube have a real existence.'",
          "'There I object,' said Filby. 'Of course a solid body may exist. All real things—'",
          "'So most people think. But wait a moment. Can an instantaneous cube exist?'",
          "'Don't follow you,' said Filby.",
          "'Can a cube that does not last for any time at all, have a real existence?'",
          "Filby became pensive. 'Clearly,' the Time Traveller proceeded, 'any real body must have extension in four directions: it must have Length, Breadth, Thickness, and—Duration. But through a natural infirmity of the flesh, which I will explain to you in a moment, we incline to overlook this fact. There are really four dimensions, three which we call the three planes of Space, and a fourth, Time.'"
        ]
      },
      {
        id: 'time_ch2',
        number: 2,
        title: "II. The Time Machine",
        paragraphs: [
          "'I want you to clearly understand that I am not inventing a ghost story or a spiritualist illusion,' the Time Traveller said, with a quiet intensity. He stood by the mantelpiece, gesturing to a small, glistening mechanism that sat on the table before us.",
          "It was a glittering metallic frame, scarcely larger than a small clock, and very delicately made. There was ivory in it, and some transparent crystalline substance. And now I must be as explicit as possible, for what follows—be the explanation what it will—is an absolutely unaccountable thing.",
          "He took one of the little levers and placed his thumb on it. 'This lever,' he said, pointing to a small brass bar, 'sends the machine into the future when pressed down, and this other reverses the motion. Here is the seat for the traveller, and once I turn this dial, I began moving through time.'",
          "We leaned forward, inspecting the strange apparatus. The Psychologist took it in his hand and turned it around, peering through the gears. It was so beautifully and solidly engineered that we could hardly suspect any trickery.",
          "'Do you mean to say,' said Filby, 'that you have actually travelled in this thing?'",
          "'I have,' said the Time Traveller, looking us straight in the eye. 'And I am prepared to show you the physical proofs of my voyage.'"
        ]
      }
    ]
  },
  {
    id: 'picture_dorian_gray',
    title: "The Picture of Dorian Gray",
    author: "Oscar Wilde",
    year: "1890",
    genre: ["Classics", "Gothic", "Philosophical"],
    description: "A handsome young man, Dorian Gray, sells his soul to ensure that an exquisite portrait of him painted by Basil Hallward ages and bears the scars of his sins, while he remains young and beautiful forever.",
    coverEmoji: "🪞",
    coverBg: "linear-gradient(135deg, #4A0E4E 0%, #1A002C 100%)",
    rating: 4.9,
    readersCount: 38400,
    estimatedReadTime: "1.8 hours",
    chapters: [
      {
        id: 'dorian_ch1',
        number: 1,
        title: "I. The Studio of Basil Hallward",
        paragraphs: [
          "The artist’s studio was filled with the rich odour of roses, and when the light summer wind stirred amidst the trees of the garden, there came through the open door the heavy scent of the lilac, or the more delicate perfume of the pink-flowered thorn.",
          "From the corner of the divan of Persian saddle-bags on which he was lying, smoking, as was his custom, innumerable cigarettes, Lord Henry Wotton could just catch the gleam of the honey-sweet and honey-coloured blossoms of a laburnum, whose tremulous branches seemed hardly able to bear the burden of a beauty so flamelike as theirs; and now and then the fantastic shadows of birds in flight flitted across the long tussore-silk curtains that were stretched in front of the huge window, producing a kind of momentary Japanese effect, and making him think of those pallid, jade-faced painters of Tokyo who, through the medium of an art that is necessarily static, seek to convey the sense of swiftness and motion.",
          "In the centre of the room, clamped to an upright easel, stood the full-length portrait of a young man of extraordinary personal beauty, and in front of it, some little distance away, was sitting the artist himself, Basil Hallward, whose sudden disappearance some years ago caused, at the time, such public excitement and gave rise to so many strange conjectures.",
          "As the painter looked at the gracious and comely form he had so skilfully mirrored in his art, a smile of pleasure passed across his face, and seemed about to linger there. But he suddenly started up, and closing his eyes, placed his fingers upon his lids, as though he sought to imprison within his brain some curious dream from which he feared he might awake.",
          "'It is your best work, Basil, the best thing you have ever done,' said Lord Henry languidly. 'You must certainly send it next year to the Grosvenor. The Academy is too large and too vulgar. Whenever I have gone there, there have been either so many people that I have not been able to see the pictures, which was dreadful, or so many pictures that I have not been able to see the people, which was worse. The Grosvenor is really the only place.'"
        ]
      }
    ]
  }
];

// Rich custom definition cache directly integrated into the client application
export const DICTIONARY_DATABASE: Record<string, { pronunciation: string; definition: string; etymology?: string }> = {
  recondite: {
    pronunciation: "/ˈrek.ən.daɪt/",
    definition: "Little known; abstruse, profound, or obscure. Information that is difficult for an ordinary person to understand.",
    etymology: "From Latin reconditus 'hidden, put away'."
  },
  incandescent: {
    pronunciation: "/ˌɪn.kænˈdes.ənt/",
    definition: "Emitting light as a result of being heated. Extremely angry, passionate, or full of strong emotion.",
    etymology: "From Latin incandescere 'to glow'."
  },
  vermin: {
    pronunciation: "/ˈvɜː.mɪn/",
    definition: "Wild animals or insects which are believed to be harmful to crops, game, or which carry disease.",
    etymology: "From Old French vermine, based on Latin vermis 'worm'."
  },
  reversion: {
    pronunciation: "/rɪˈvɜː.ʃən/",
    definition: "A return to a previous state, practice, or belief. The right of possessing or succeeding to property.",
    etymology: "From Latin reversio."
  },
  aesthetic: {
    pronunciation: "/esˈθet.ɪk/",
    definition: "Concerned with beauty or the appreciation of beauty. A set of principles underlying the work of a particular artist.",
    etymology: "From Greek aisthētikos 'perceptive, sensitive'."
  },
  whimsical: {
    pronunciation: "/ˈwɪm.zɪ.kəl/",
    definition: "Playfully quaint or fanciful, especially in an appealing and amusing way. Acting in a capricious manner.",
    etymology: "From whim, a caprice or sudden fancy."
  },
  melancholy: {
    pronunciation: "/ˈmel.əŋ.kɒl.i/",
    definition: "A feeling of pensive sadness, typically with no obvious cause.",
    etymology: "From Greek melas 'black' + kholē 'bile'."
  },
  languidly: {
    pronunciation: "/ˈlæŋ.ɡwɪd.li/",
    definition: "In a way that lacks energy or enthusiasm; slowly and lazily.",
    etymology: "From French languide, Latin languidus."
  },
  curiosity: {
    pronunciation: "/ˌkjʊə.riˈɒs.ɪ.ti/",
    definition: "A strong desire to know or learn something; a strange or unusual object or fact.",
    etymology: "From Latin curiositas."
  }
};
