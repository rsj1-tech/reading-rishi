export interface Chapter {
  id: string;
  number: number;
  title: string;
  paragraphs: string[];
}

export interface Book {
  id: string;
  title: string;
  author: string;
  year: string;
  genre: string[];
  description: string;
  coverEmoji: string;
  coverBg: string;
  chapters: Chapter[];
  rating: number;
  readersCount: number;
  estimatedReadTime: string; // e.g. "45 min"
}

export interface Highlight {
  id: string;
  bookId: string;
  chapterId: string;
  text: string;
  color: 'yellow' | 'blue' | 'green' | 'pink';
  note?: string;
  createdAt: string;
}

export interface SavedPosition {
  bookId: string;
  chapterIndex: number;
  paragraphIndex: number;
  scrollOffsetPct: number;
  updatedAt: string;
}

export interface UserStats {
  streak: number;
  lastReadDate: string | null;
  dailyGoalMinutes: number;
  todayMinutesRead: number;
  totalChaptersCompleted: number;
}
