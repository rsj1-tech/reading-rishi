import React, { useState } from 'react';
import { Book, Highlight, UserStats } from '../types';
import {
  Flame,
  Award,
  BookMarked,
  Trash2,
  ListTodo,
  Check,
  Calendar,
  Clock,
  ExternalLink,
  Plus,
  BookOpen
} from 'lucide-react';
import AudioPlayer from './AudioPlayer';

interface DashboardProps {
  books: Book[];
  userStats: UserStats;
  onUpdateStats: (stats: UserStats) => void;
  highlights: Highlight[];
  onDeleteHighlight: (hlId: string) => void;
  onJumpToQuote: (bookId: string, chapterId: string) => void;
}

export default function Dashboard({
  books,
  userStats,
  onUpdateStats,
  highlights,
  onDeleteHighlight,
  onJumpToQuote,
}: DashboardProps) {
  const [logTimeMinutes, setLogTimeMinutes] = useState(15);
  const percentComplete = Math.min(100, Math.round((userStats.todayMinutesRead / userStats.dailyGoalMinutes) * 100));

  // Handle logging read time manually to boost progress circle ring
  const handleLogReadingMinutes = () => {
    const updatedStats = {
      ...userStats,
      todayMinutesRead: userStats.todayMinutesRead + logTimeMinutes,
    };
    onUpdateStats(updatedStats);
    setLogTimeMinutes(15);
  };

  const incrementDailyGoal = (amount: number) => {
    const updatedStats = {
      ...userStats,
      dailyGoalMinutes: Math.max(5, userStats.dailyGoalMinutes + amount),
    };
    onUpdateStats(updatedStats);
  };

  return (
    <div className="space-y-6">
      
      {/* 1. Daily Reading Goal SVG circular tracker */}
      <div className="bg-[#18092d]/65 backdrop-blur-md border border-purple-500/20 rounded-3xl p-6 shadow-lg shadow-purple-950/20 relative overflow-hidden flex flex-col items-center text-center">
        <h3 className="font-serif font-black text-pink-400 text-base mb-4 flex items-center gap-1.5 w-full">
          <Clock className="w-5 h-5 text-[#f06292]" /> Daily Reading Circle
        </h3>

        <div className="relative w-36 h-36 mb-4">
          <svg className="w-full h-full transform -rotate-90">
            {/* Background tracking circle ring */}
            <circle
              cx="72"
              cy="72"
              r="60"
              className="stroke-purple-900/40"
              strokeWidth="8"
              fill="transparent"
            />
            {/* Foreground progress indicator */}
            <circle
              cx="72"
              cy="72"
              r="60"
              className="stroke-pink-550 transition-all duration-500 ease-out text-[#f06292] stroke-pink-500"
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={`${2 * Math.PI * 60}`}
              strokeDashoffset={`${2 * Math.PI * 60 * (1 - percentComplete / 100)}`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center font-sans">
            <span className="text-2xl font-black text-white leading-none">
              {percentComplete}%
            </span>
            <span className="text-[10px] uppercase tracking-wider text-purple-300/80 mt-1">
              {userStats.todayMinutesRead} / {userStats.dailyGoalMinutes} min
            </span>
          </div>
        </div>

        {/* Adjust target goals or manually log sessions */}
        <div className="w-full space-y-3 pt-2 text-xs font-sans">
          <div className="flex justify-between items-center bg-[#100424]/65 px-3.5 py-2.5 rounded-2xl border border-purple-500/15">
            <span className="text-purple-300">Daily Target:</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => incrementDailyGoal(-5)}
                className="w-5 h-5 bg-purple-900/60 rounded-full flex items-center justify-center font-bold hover:bg-purple-800 text-purple-200 cursor-pointer"
              >
                -
              </button>
              <span className="font-bold text-[#2ffff5]">{userStats.dailyGoalMinutes}m</span>
              <button
                onClick={() => incrementDailyGoal(5)}
                className="w-5 h-5 bg-purple-900/60 rounded-full flex items-center justify-center font-bold hover:bg-purple-800 text-purple-200 cursor-pointer"
              >
                +
              </button>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => {
                setLogTimeMinutes(15);
                handleLogReadingMinutes();
              }}
              className="flex-1 bg-gradient-to-r from-[#ff6b6b] to-[#f06292] hover:scale-[1.02] active:scale-[0.98] text-white font-bold py-2.5 rounded-2xl shadow-lg shadow-pink-500/25 transition-all flex items-center justify-center gap-1.5 cursor-pointer text-xs"
            >
              <Plus className="w-3.5 h-3.5 animate-pulse" /> Log 15m Read
            </button>
          </div>
        </div>
      </div>

      {/* 2. Audio Ambiance direct Synthesizer block */}
      <AudioPlayer />

      {/* 3. Streaks & Accomplishments (Weekly Calendar grid) */}
      <div className="bg-[#18092d]/65 backdrop-blur-md border border-purple-500/20 rounded-3xl p-6 shadow-lg shadow-purple-950/20 relative">
        <h3 className="font-serif font-black text-pink-400 text-base mb-2 flex items-center gap-1.5">
          <Flame className="w-5 h-5 text-pink-500 animate-pulse fill-pink-500/25" /> Reading Streak Calendar
        </h3>
        <p className="text-[11px] text-purple-300/80 mb-4 font-sans leading-relaxed">
          Log reading sessions to secure your consecutive flame streak!
        </p>

        <div className="flex flex-col items-center justify-center bg-pink-500/10 py-3.5 rounded-2xl border border-pink-500/20 mb-5 text-center">
          <span className="text-3xl font-serif font-black text-transparent bg-gradient-to-r from-pink-400 via-[#f06292] to-[#da3fff] bg-clip-text">
            {userStats.streak} Days
          </span>
          <span className="text-[9px] uppercase tracking-wider font-semibold text-purple-300 mt-1">
            Current Unbroken Run
          </span>
        </div>

        {/* Mon-Sun tracker checklist */}
        <div className="grid grid-cols-7 gap-1 font-sans">
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, idx) => {
            const isCompleted = idx < 6; // Representing standard current week status completed except Sunday
            return (
              <div key={idx} className="flex flex-col items-center">
                <span className="text-[10px] text-purple-400 mb-1 font-semibold">{day}</span>
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                    isCompleted
                      ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/20 scale-102 transform hover:scale-110'
                      : 'bg-[#100424]/40 text-purple-400/40 border border-purple-500/10'
                  }`}
                  title={isCompleted ? "Day Read Complete!" : "Scheduled Target"}
                >
                  {isCompleted ? <Check className="w-3.5 h-3.5" /> : idx}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Active Annotations & Highlights directory */}
      <div className="bg-[#18092d]/65 backdrop-blur-md border border-purple-500/20 rounded-3xl p-6 shadow-lg shadow-purple-950/20 relative">
        <h3 className="font-serif font-black text-pink-400 text-base mb-1 flex items-center gap-1.5">
          <BookMarked className="w-5 h-5 text-pink-500" /> Annotations Collection
        </h3>
        <p className="text-[11px] text-purple-305 mb-4 font-sans leading-relaxed">
          All underlined quotes and custom notes taken across your books. Click any item to jump instantly to the pages.
        </p>

        {highlights.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-xs text-purple-400/80">No highlights recorded yet!</p>
            <p className="text-[10px] text-purple-400/50 mt-1">Select text inside any text page to highlight or save quotes.</p>
          </div>
        ) : (
          <div className="space-y-3.5 max-h-80 overflow-y-auto pr-1">
            {highlights.map((hl) => {
              const bookObj = books.find((b) => b.id === hl.bookId);
              return (
                <div
                  key={hl.id}
                  className="bg-[#120626] p-3.5 rounded-2xl border border-purple-500/20 flex flex-col justify-between relative group hover:border-pink-500/50 transition-colors animate-fadeIn"
                >
                  <div className="mb-2">
                    {/* Color categorizer */}
                    <span
                      className={`inline-block w-2.5 h-2.5 rounded-full mr-2 ${
                        hl.color === 'yellow' ? 'bg-yellow-300' :
                        hl.color === 'blue' ? 'bg-cyan-300 shadow-[0_0_8px_rgba(34,211,238,0.5)]' :
                        hl.color === 'green' ? 'bg-emerald-300' :
                        'bg-pink-400 shadow-[0_0_8px_rgba(244,114,182,0.5)]'
                      }`}
                    />
                    <span className="text-[10px] font-bold text-[#faf5ff]/40 font-sans">
                      {bookObj?.title || 'Unknown Book'}
                    </span>
                  </div>

                  <p className="text-xs italic text-purple-100 line-clamp-3 mb-2 font-serif bg-[#18092d]/40 p-2.5 rounded-xl border border-purple-500/10">
                    "{hl.text}"
                  </p>

                  {hl.note && (
                    <div className="text-xs text-pink-400 font-semibold mb-2 font-sans pl-2.5 border-l-2 border-pink-500 leading-relaxed">
                      💬 Note: {hl.note}
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <span className="text-[9px] text-purple-400/60 font-mono">
                      {new Date(hl.createdAt).toLocaleDateString()}
                    </span>
                    
                    <div className="flex gap-2 opacity-100 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onJumpToQuote(hl.bookId, hl.chapterId)}
                        className="text-[10px] font-mono text-pink-400 hover:text-pink-350 flex items-center gap-0.5 cursor-pointer"
                        title="Jump to block segment"
                      >
                        <BookOpen className="w-3.5 h-3.5" /> Jump
                      </button>
                      <button
                        onClick={() => onDeleteHighlight(hl.id)}
                        className="text-[10px] font-mono text-red-400 hover:text-red-300 flex items-center gap-0.5 cursor-pointer"
                        title="Delete Annotation"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
