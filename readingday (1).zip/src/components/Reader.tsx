import React, { useState, useEffect, useRef } from 'react';
import { Book, Highlight, SavedPosition } from '../types';
import { DICTIONARY_DATABASE } from '../data/books';
import {
  X,
  Type,
  ChevronLeft,
  ChevronRight,
  Bookmark,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  BookOpen,
  MousePointerClick,
  Plus,
  Trash2,
  Check,
  Search,
  BookMarked
} from 'lucide-react';

interface ReaderProps {
  book: Book;
  onClose: () => void;
  savedPosition?: SavedPosition;
  onSavePosition: (position: SavedPosition) => void;
  highlights: Highlight[];
  onAddHighlight: (hl: Highlight) => void;
  onDeleteHighlight: (hlId: string) => void;
  onUpdateHighlightNote: (hlId: string, note: string) => void;
}

export default function Reader({
  book,
  onClose,
  savedPosition,
  onSavePosition,
  highlights,
  onAddHighlight,
  onDeleteHighlight,
  onUpdateHighlightNote,
}: ReaderProps) {
  // Current position state
  const [currentChapterIdx, setCurrentChapterIdx] = useState(savedPosition?.bookId === book.id ? savedPosition.chapterIndex : 0);
  const currentChapter = book.chapters[currentChapterIdx] || book.chapters[0];

  // Visual/Typography Preference state
  const [theme, setTheme] = useState<'paper' | 'sepia' | 'slate' | 'dusky' | 'midnight' | 'forest'>('paper');
  const [fontFamily, setFontFamily] = useState<'font-lora' | 'font-playfair' | 'font-source' | 'font-noto' | 'font-opendyslexic'>('font-lora');
  const [fontSize, setFontSize] = useState(17);
  const [lineHeight, setLineHeight] = useState(1.75);
  const [letterSpacing, setLetterSpacing] = useState('normal'); // normal, wide, extra-wide
  const [marginWidth, setMarginWidth] = useState<'narrow' | 'compact' | 'cozy' | 'wide'>('cozy');

  // UI Control States
  const [isStylePanelOpen, setIsStylePanelOpen] = useState(false);
  const [speedReaderOpen, setSpeedReaderOpen] = useState(false);
  const [autoScrollSpeed, setAutoScrollSpeed] = useState(0); // 0 = off, 1 = slow, 5 = fast

  // Text-to-Speech (TTS) State
  const [isTtsPlaying, setIsTtsPlaying] = useState(false);
  const [ttsRate, setTtsRate] = useState(1.0);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [voiceList, setVoiceList] = useState<SpeechSynthesisVoice[]>([]);

  // Selection & Highlight action state
  const [floatingMenu, setFloatingMenu] = useState<{ x: number; y: number; text: string } | null>(null);
  const [activeHighlightId, setActiveHighlightId] = useState<string | null>(null);
  const [noteInputValue, setNoteInputValue] = useState('');
  const [dictionaryWord, setDictionaryWord] = useState<{ word: string; pron: string; def: string } | null>(null);

  // RSVP Speed Reader engine state
  const [rsvpWpm, setRsvpWpm] = useState(300);
  const [rsvpIsPlaying, setRsvpIsPlaying] = useState(false);
  const [rsvpCurrentWordIdx, setRsvpCurrentWordIdx] = useState(0);
  const rsvpIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const scrollContainerRef = useRef<HTMLDivElement | null>(null);
  const topBarRef = useRef<HTMLDivElement | null>(null);
  const autoScrollTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Estimated reading progress depth percentage
  const [scrollPct, setScrollPct] = useState(0);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg(prev => prev === msg ? null : prev);
    }, 3500);
  };

  // Initialize Speech synthesis voices
  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      const getVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setVoiceList(voices.filter(v => v.lang.startsWith('en')));
        if (voices.length > 0 && !selectedVoice) {
          setSelectedVoice(voices.find(v => v.default && v.lang.startsWith('en')) || voices[0]);
        }
      };
      getVoices();
      window.speechSynthesis.onvoiceschanged = getVoices;
    }
  }, []);

  // Update scroll percentage of page
  const handleScroll = () => {
    if (scrollContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
      const totalScroll = scrollHeight - clientHeight;
      if (totalScroll > 0) {
        const pct = Math.round((scrollTop / totalScroll) * 100);
        setScrollPct(pct);
      }
    }
  };

  // Safe TTS stop
  const stopTts = () => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setIsTtsPlaying(false);
    }
  };

  // Core TTS Speecher
  const startTts = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    
    stopTts();
    const textToRead = currentChapter.paragraphs.join(' ');
    const utterance = new SpeechSynthesisUtterance(textToRead);
    
    if (selectedVoice) {
      utterance.voice = selectedVoice;
    }
    utterance.rate = ttsRate;
    
    utterance.onend = () => {
      setIsTtsPlaying(false);
    };
    utterance.onerror = () => {
      setIsTtsPlaying(false);
    };

    window.speechSynthesis.speak(utterance);
    setIsTtsPlaying(true);
  };

  // RSVP Speed reading word breakdown
  const getAllBookWords = () => {
    return currentChapter.paragraphs.join(' ').replace(/[\r\n]+/g, ' ').split(/\s+/).filter(Boolean);
  };
  const words = getAllBookWords();

  // RSVP Interval ticker
  useEffect(() => {
    if (rsvpIsPlaying) {
      const speedMs = (60 / rsvpWpm) * 1000;
      rsvpIntervalRef.current = setInterval(() => {
        setRsvpCurrentWordIdx((prev) => {
          if (prev >= words.length - 1) {
            setRsvpIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, speedMs);
    } else {
      if (rsvpIntervalRef.current) clearInterval(rsvpIntervalRef.current);
    }

    return () => {
      if (rsvpIntervalRef.current) clearInterval(rsvpIntervalRef.current);
    };
  }, [rsvpIsPlaying, rsvpWpm, words.length]);

  // Autoscroll vertical ticker
  useEffect(() => {
    if (autoScrollSpeed > 0 && scrollContainerRef.current) {
      const intervalMs = 100 / autoScrollSpeed;
      autoScrollTimerRef.current = setInterval(() => {
        if (scrollContainerRef.current) {
          scrollContainerRef.current.scrollTop += 1;
        }
      }, intervalMs);
    } else {
      if (autoScrollTimerRef.current) clearInterval(autoScrollTimerRef.current);
    }

    return () => {
      if (autoScrollTimerRef.current) clearInterval(autoScrollTimerRef.current);
    };
  }, [autoScrollSpeed]);

  // Tracking user selections to trigger floating annotation bubble
  const handleTextSelection = (e: React.MouseEvent) => {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) {
      // Check if we clicked on an existing highlight
      const target = e.target as HTMLElement;
      if (target.tagName === 'MARK' && target.dataset.id) {
        const hlId = target.dataset.id;
        const hl = highlights.find(h => h.id === hlId);
        if (hl) {
          setActiveHighlightId(hlId);
          setNoteInputValue(hl.note || '');
        }
      } else {
        setFloatingMenu(null);
      }
      return;
    }

    const text = selection.toString().trim();
    if (text.length > 0) {
      const range = selection.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      setFloatingMenu({
        x: rect.left + window.scrollX + rect.width / 2,
        y: rect.top + window.scrollY - 44,
        text,
      });
    }
  };

  const createHighlight = (color: 'yellow' | 'blue' | 'green' | 'pink') => {
    if (!floatingMenu) return;
    const newHl: Highlight = {
      id: `hl_${Date.now()}`,
      bookId: book.id,
      chapterId: currentChapter.id,
      text: floatingMenu.text,
      color,
      createdAt: new Date().toISOString(),
    };
    onAddHighlight(newHl);
    setFloatingMenu(null);
    window.getSelection()?.removeAllRanges();
    setActiveHighlightId(newHl.id);
    setNoteInputValue('');
  };

  const explainWord = () => {
    if (!floatingMenu) return;
    const cleanWord = floatingMenu.text.toLowerCase().replace(/[^a-z'-]/g, '');
    const entry = DICTIONARY_DATABASE[cleanWord];
    
    if (entry) {
      setDictionaryWord({
        word: floatingMenu.text,
        pron: entry.pronunciation,
        def: entry.definition,
      });
    } else {
      setDictionaryWord({
        word: floatingMenu.text,
        pron: "/.../",
        def: `Contextual definition for "${floatingMenu.text}": Read closely in your current selection! Use your integrated high-fidelity reading dictionary to grasp this vocabulary seamlessly.`,
      });
    }
    setFloatingMenu(null);
    window.getSelection()?.removeAllRanges();
  };

  const handleUpdateNote = () => {
    if (activeHighlightId) {
      onUpdateHighlightNote(activeHighlightId, noteInputValue);
      setActiveHighlightId(null);
    }
  };

  // Save current progress to container states
  const triggerSavePosition = (targetChapIdx = currentChapterIdx) => {
    onSavePosition({
      bookId: book.id,
      chapterIndex: targetChapIdx,
      paragraphIndex: 0,
      scrollOffsetPct: scrollPct,
      updatedAt: new Date().toISOString(),
    });
  };

  const changeChapter = (direction: 'next' | 'prev') => {
    stopTts();
    let target = currentChapterIdx;
    if (direction === 'next' && currentChapterIdx < book.chapters.length - 1) {
      target = currentChapterIdx + 1;
    } else if (direction === 'prev' && currentChapterIdx > 0) {
      target = currentChapterIdx - 1;
    }
    setCurrentChapterIdx(target);
    setScrollPct(0);
    if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = 0;
    triggerSavePosition(target);
  };

  useEffect(() => {
    return () => {
      stopTts();
      if (rsvpIntervalRef.current) clearInterval(rsvpIntervalRef.current);
      if (autoScrollTimerRef.current) clearInterval(autoScrollTimerRef.current);
    };
  }, []);

  // Filter highlights specifically matching the current chapter segment
  const currentChapterHighlights = highlights.filter(
    (h) => h.bookId === book.id && h.chapterId === currentChapter.id
  );

  // Render original clean text while embedding highlighted fragments elegantly
  const renderParagraphWithHighlights = (paraText: string, paraIdx: number) => {
    // Find highlights that overlap with this paragraph
    const matches = currentChapterHighlights.filter(h => paraText.includes(h.text));
    
    if (matches.length === 0) {
      return <p key={paraIdx} className="mb-6 leading-relaxed text-stone-850 dark:text-stone-150">{paraText}</p>;
    }

    // Sort overlaps by text index to split sequentially
    let indexedMatches = matches.map(m => ({
      ...m,
      startIdx: paraText.indexOf(m.text),
      endIdx: paraText.indexOf(m.text) + m.text.length
    })).sort((a, b) => a.startIdx - b.startIdx);

    const elements: React.ReactNode[] = [];
    let lastIdx = 0;

    indexedMatches.forEach((hl, i) => {
      if (hl.startIdx > lastIdx) {
        elements.push(paraText.substring(lastIdx, hl.startIdx));
      }
      elements.push(
        <mark
          key={`mark_${hl.id}_${i}`}
          data-id={hl.id}
          className={`px-0.5 rounded-sm cursor-pointer border-b border-dashed transition-all transition-colors duration-200 ${
            hl.color === 'yellow' ? 'bg-yellow-200/80 dark:bg-yellow-950/50 text-stone-900 dark:text-yellow-100 border-yellow-400' :
            hl.color === 'blue' ? 'bg-blue-200/80 dark:bg-blue-950/50 text-stone-900 dark:text-blue-100 border-blue-400' :
            hl.color === 'green' ? 'bg-emerald-200/80 dark:bg-emerald-950/50 text-stone-900 dark:text-emerald-100 border-emerald-400' :
            'bg-pink-200/80 dark:bg-pink-950/50 text-stone-900 dark:text-pink-100 border-pink-400'
          }`}
          title={hl.note ? `Note: ${hl.note}` : 'Click to view highlights.'}
        >
          {hl.text}
        </mark>
      );
      lastIdx = hl.endIdx;
    });

    if (lastIdx < paraText.length) {
      elements.push(paraText.substring(lastIdx));
    }

    return (
      <p key={paraIdx} className="mb-6 leading-relaxed text-stone-850 dark:text-stone-150">
        {elements}
      </p>
    );
  };

  // Setup theme-specific styling classes
  const themeClasses = 
    theme === 'sepia' ? 'bg-[#210d1f] text-[#ffd3ff]' :
    theme === 'slate' ? 'bg-[#18082c] text-[#e3c1ff]' :
    theme === 'dusky' ? 'bg-[#0d041b] text-[#ffd6fb]' :
    theme === 'midnight' ? 'bg-[#05010b] text-[#2ffff5]' :
    theme === 'forest' ? 'bg-[#030e16] text-[#3affdf]' :
    'bg-[#0e051d] text-[#fae8ff]';

  const fontStyle = 
    fontFamily === 'font-playfair' ? 'font-serif tracking-tight' :
    fontFamily === 'font-source' ? 'font-sans' :
    fontFamily === 'font-noto' ? 'font-serif font-medium' :
    fontFamily === 'font-opendyslexic' ? 'font-serif animate-pulse text-[1.05em]' :
    'font-serif';

  const marginStyle = 
    marginWidth === 'narrow' ? 'max-w-md' :
    marginWidth === 'compact' ? 'max-w-lg' :
    marginWidth === 'wide' ? 'max-w-3xl' :
    'max-w-2xl';

  return (
    <div className={`fixed inset-0 z-50 flex flex-col font-sans transition-all duration-300 ${themeClasses}`}>
      
      {/* Floating dynamic non-blocking toast notification */}
      {toastMsg && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-55 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-sans text-xs font-bold px-4 [word-spacing:1px] py-2.5 rounded-2xl shadow-xl shadow-pink-500/25 border border-pink-400 border-opacity-40 animate-bounce flex items-center gap-2">
          <span>✨ {toastMsg}</span>
        </div>
      )}

      {/* Dynamic scrolling depth progress indicator */}
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 z-50 transition-all duration-100 shadow-[0_0_8px_#ff00a0]"
        style={{ width: `${scrollPct}%` }}
      />

      {/* Primary header toolbar */}
      <header
        ref={topBarRef}
        className="flex items-center justify-between px-6 py-3 border-b border-purple-500/20 bg-[#160a28]/85 backdrop-blur-md z-40"
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              stopTts();
              onClose();
            }}
            className="p-2 py-1.5 rounded-xl border border-purple-500/30 bg-[#120524]/60 hover:bg-pink-500/10 text-purple-200 hover:text-white font-sans text-xs flex items-center gap-1 cursor-pointer transition-colors"
          >
            <ChevronLeft className="w-4 h-4" /> Library
          </button>
          <div>
            <div className="text-xs text-purple-300 font-sans flex items-center gap-1 truncate max-w-[150px] sm:max-w-[220px]">
              {book.author} · <span className="text-pink-400 font-bold">{scrollPct}% read</span>
            </div>
            <h3 className="text-xs sm:text-sm font-serif font-black line-clamp-1 text-white">
              {book.title}
            </h3>
          </div>
        </div>

        {/* Toolbar toolset operations */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Quick style panel button */}
          <button
            onClick={() => setIsStylePanelOpen(!isStylePanelOpen)}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              isStylePanelOpen
                ? 'bg-[#f06292] text-[#faf5ff] border-[#f06292] shadow-md shadow-pink-500/20'
                : 'bg-[#1a0b38] hover:bg-[#230f49] text-purple-200 border-purple-500/20'
            }`}
            title="Formatting & Preferences"
          >
            <Type className="w-4.5 h-4.5" />
          </button>

          {/* Quick Speed Reader RSVP button */}
          <button
            onClick={() => setSpeedReaderOpen(!speedReaderOpen)}
            className={`p-2 rounded-xl border transition-all cursor-pointer flex items-center gap-1 text-xs font-serif ${
              speedReaderOpen
                ? 'bg-[#8338ec] text-[#faf5ff] border-[#8338ec] font-bold shadow-md shadow-purple-500/20'
                : 'bg-[#1a0b38] hover:bg-[#230f49] text-purple-200 border-purple-500/20'
            }`}
            title="RSVP Speed Reading Assist"
          >
            <Sparkles className="w-4 h-4" /> <span className="hidden sm:inline">Speed Read</span>
          </button>

          {/* Read Aloud button */}
          <button
            onClick={isTtsPlaying ? stopTts : startTts}
            className={`p-2 rounded-xl border transition-all cursor-pointer ${
              isTtsPlaying
                ? 'bg-pink-600 text-[#faf5ff] border-pink-600 animate-pulse shadow-md shadow-pink-500/25'
                : 'bg-[#1a0b38] hover:bg-[#230f49] text-purple-200 border-purple-500/20'
            }`}
            title="Read Aloud segment"
          >
            {isTtsPlaying ? <Volume2 className="w-4.5 h-4.5 animate-bounce" /> : <VolumeX className="w-4.5 h-4.5" />}
          </button>

          {/* Bookmark page position */}
          <button
            onClick={() => {
              triggerSavePosition();
              showToast(`Progress saved inside Chapter ${currentChapter.number}!`);
            }}
            className="p-2 rounded-xl bg-[#1a0b38] hover:bg-[#230f49] hover:text-pink-400 text-purple-200 border border-purple-500/20 cursor-pointer transition-colors"
            title="Bookmark reading depth"
          >
            <Bookmark className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      {/* Sub-toolbar: TTS / Voice panel if TTS is active */}
      {isTtsPlaying && (
        <div className="bg-amber-50/90 dark:bg-stone-950/80 px-6 py-2 border-b border-stone-200/40 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-300 sm:flex items-center gap-4 justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-amber-600 dark:text-amber-400 flex items-center gap-1">
              <Volume2 className="w-4.5 h-4.5" /> Read Aloud Engine Active
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span>Voice:</span>
              <select
                value={selectedVoice?.name || ''}
                onChange={(e) => {
                  const voice = voiceList.find(v => v.name === e.target.value);
                  if (voice) setSelectedVoice(voice);
                }}
                className="bg-white/60 dark:bg-stone-850 border border-stone-300 dark:border-stone-750 rounded-lg px-2 py-0.5 max-w-[130px] sm:max-w-[200px]"
              >
                {voiceList.map(v => (
                  <option key={v.name} value={v.name}>{v.name} ({v.lang})</option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-1.5">
              <span>Speed:</span>
              <select
                value={ttsRate}
                onChange={(e) => {
                  setTtsRate(parseFloat(e.target.value));
                  startTts(); // restart with new speed
                }}
                className="bg-white/60 dark:bg-stone-850 border border-stone-300 dark:border-stone-750 rounded-lg px-2 py-0.5"
              >
                <option value="0.8">0.8x</option>
                <option value="1.0">1.0x</option>
                <option value="1.2">1.2x</option>
                <option value="1.5">1.5x</option>
                <option value="1.8">1.8x</option>
              </select>
            </div>
            <button
              onClick={stopTts}
              className="px-2 py-0.5 bg-red-500 text-white rounded-lg font-sans font-bold"
            >
              Stop
            </button>
          </div>
        </div>
      )}

      {/* Main viewport & Speed reading split layout */}
      <div className="flex-1 overflow-hidden relative flex flex-col md:flex-row">
        
        {/* Core Book scroll container */}
        <div
          ref={scrollContainerRef}
          onScroll={handleScroll}
          onMouseUp={handleTextSelection}
          className="flex-1 overflow-y-auto px-6 py-10 select-text relative scroll-smooth cursor-text"
        >
          <div className={`mx-auto ${marginStyle} ${fontStyle}`}>
            
            {/* Speecher Auto scroll overlay stats block */}
            {autoScrollSpeed > 0 && (
              <div className="fixed bottom-6 right-6 bg-amber-500 text-white px-3 py-1.5 rounded-full text-xs font-sans shadow-lg flex items-center gap-1 z-30 animate-pulse">
                <span>Autoscrolling... Speed {autoScrollSpeed}</span>
                <button
                  onClick={() => setAutoScrollSpeed(0)}
                  className="bg-white/20 p-0.5 rounded-full hover:bg-white/40"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}

            {/* Book Title Header */}
            <div className="mb-10 text-center">
              <span className="text-amber-500 font-serif font-black tracking-widest uppercase text-xs sm:text-sm block mb-2">
                Chapter {currentChapter.number}
              </span>
              <h1 className="font-serif font-black text-3xl sm:text-4xl text-stone-900 dark:text-stone-50 leading-tight mb-4 tracking-tight">
                {currentChapter.title}
              </h1>
              <div className="w-16 h-0.5 bg-amber-500/50 mx-auto rounded-full" />
            </div>

            {/* Chapter Paragraph contents loaded dynamically with Highlight binding */}
            <div className="space-y-6 text-base sm:text-lg leading-relaxed text-stone-800 dark:text-stone-150 relative">
              {currentChapter.paragraphs.map((para, paraIdx) => 
                renderParagraphWithHighlights(para, paraIdx)
              )}
            </div>

            {/* Book Footer chapter switcher */}
            <div className="mt-16 pt-8 border-t border-stone-200/40 dark:border-stone-800/80 flex justify-between items-center font-sans">
              <button
                onClick={() => changeChapter('prev')}
                disabled={currentChapterIdx === 0}
                className="px-4 py-2 bg-stone-100 dark:bg-stone-850 hover:bg-stone-200 disabled:opacity-30 rounded-xl text-xs sm:text-sm flex items-center gap-1 text-stone-600 dark:text-stone-300 transition-all font-semibold cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" /> Previous Chapter
              </button>

              <span className="text-xs text-stone-400 dark:text-stone-500">
                Chapter {currentChapterIdx + 1} of {book.chapters.length}
              </span>

              <button
                onClick={() => changeChapter('next')}
                disabled={currentChapterIdx === book.chapters.length - 1}
                className="px-4 py-2 bg-stone-100 dark:bg-stone-850 hover:bg-stone-200 disabled:opacity-30 rounded-xl text-xs sm:text-sm flex items-center gap-1 text-stone-600 dark:text-stone-300 transition-all font-semibold cursor-pointer"
              >
                Next Chapter <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

        {/* RSVP SPEED READING assist window (Slick floating container) */}
        {speedReaderOpen && (
          <div className="w-full md:w-80 border-t md:border-t-0 md:border-l border-stone-200/60 dark:border-stone-850 bg-stone-50/95 dark:bg-stone-950/85 backdrop-blur-md p-6 flex flex-col justify-between font-sans shadow-md">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-serif font-black text-amber-600 dark:text-amber-500 text-sm flex items-center gap-1">
                  <Sparkles className="w-4 h-4" /> RSVP speed reader
                </h4>
                <button
                  onClick={() => setSpeedReaderOpen(false)}
                  className="p-1 rounded-lg hover:bg-stone-200 dark:hover:bg-stone-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-[11px] text-stone-400 mb-6 leading-relaxed">
                Speed reading flashes words sequentially inside the focus block. Dramatically scales speed without saccadic vision degradation!
              </p>

              {/* RSVP focal word highlight window */}
              <div className="bg-white dark:bg-stone-900 border border-amber-200/40 dark:border-stone-800/80 rounded-2xl py-12 px-4 shadow-xs text-center relative overflow-hidden mb-6 flex items-center justify-center min-h-[140px]">
                {/* Horizontal reference focal points */}
                <span className="absolute left-[45%] top-1/2 -translate-y-1/2 text-red-500/30 text-xl pointer-events-none select-none">|</span>
                <span className="absolute right-[45%] top-1/2 -translate-y-1/2 text-red-500/30 text-xl pointer-events-none select-none">|</span>

                <div className="font-serif text-3xl font-black tracking-tight text-stone-900 dark:text-stone-50 uppercase scale-110 select-none">
                  {words[rsvpCurrentWordIdx] || 'No characters'}
                </div>
              </div>

              {/* RSVP WPM controller */}
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs text-stone-500 mb-1">
                    <span>Target WPM:</span>
                    <span className="font-bold text-amber-500">{rsvpWpm} words / min</span>
                  </div>
                  <input
                    type="range"
                    min="150"
                    max="800"
                    step="25"
                    value={rsvpWpm}
                    onChange={(e) => setRsvpWpm(parseInt(e.target.value))}
                    className="w-full accent-amber-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-stone-500 mb-1">
                    <span>Progress:</span>
                    <span>
                      {rsvpCurrentWordIdx + 1} / {words.length} terms ({Math.round(((rsvpCurrentWordIdx + 1) / words.length) * 100)}%)
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max={words.length - 1}
                    value={rsvpCurrentWordIdx}
                    onChange={(e) => setRsvpCurrentWordIdx(parseInt(e.target.value))}
                    className="w-full accent-stone-400 cursor-pointer"
                  />
                </div>
              </div>
            </div>

            {/* RSVP playing controls */}
            <div className="flex gap-2.5 items-center justify-center pt-4">
              <button
                onClick={() => setRsvpCurrentWordIdx(0)}
                className="p-2.5 rounded-full bg-stone-100 dark:bg-stone-850 hover:bg-stone-200 text-stone-600 dark:text-stone-300 cursor-pointer"
                title="Reset word ticker"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                onClick={() => setRsvpIsPlaying(!rsvpIsPlaying)}
                className="px-5 py-2 rounded-full bg-amber-500 hover:bg-amber-600 text-white font-bold flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
              >
                {rsvpIsPlaying ? <Pause className="w-4.5 h-4.5" /> : <Play className="w-4.5 h-4.5" />}
                {rsvpIsPlaying ? 'Pause' : 'Start Engine'}
              </button>
            </div>
          </div>
        )}

      </div>

      {/* Floating look-up annotation details / color highlighting menu */}
      {floatingMenu && (
        <div
          style={{ left: floatingMenu.x - 100, top: floatingMenu.y }}
          className="absolute z-50 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-full px-3 py-1.5 flex items-center gap-2.5 shadow-xl animate-fadeIn"
        >
          {/* Highlight Color options */}
          <div className="flex gap-1.5 border-r border-stone-200/60 dark:border-stone-800/80 pr-2.5">
            <button
              onClick={() => createHighlight('yellow')}
              className="w-5 h-5 rounded-full bg-yellow-200 dark:bg-yellow-950 border border-yellow-300 dark:border-yellow-800 hover:scale-110 transition-transform cursor-pointer"
              title="Highlight Yellow"
            />
            <button
              onClick={() => createHighlight('blue')}
              className="w-5 h-5 rounded-full bg-blue-200 dark:bg-blue-950 border border-blue-300 dark:border-blue-800 hover:scale-110 transition-transform cursor-pointer"
              title="Highlight Blue"
            />
            <button
              onClick={() => createHighlight('green')}
              className="w-5 h-5 rounded-full bg-emerald-200 dark:bg-emerald-950 border border-emerald-300 dark:border-emerald-800 hover:scale-110 transition-transform cursor-pointer"
              title="Highlight Emerald"
            />
            <button
              onClick={() => createHighlight('pink')}
              className="w-5 h-5 rounded-full bg-pink-200 dark:bg-pink-950 border border-pink-300 dark:border-pink-800 hover:scale-110 transition-transform cursor-pointer"
              title="Highlight Pink"
            />
          </div>

          {/* Quick explain dictionary button */}
          <button
            onClick={explainWord}
            className="text-[11px] font-semibold text-amber-600 hover:text-amber-700 select-none flex items-center gap-0.5 cursor-pointer font-serif"
          >
            <BookOpen className="w-3.5 h-3.5" /> Define Selection
          </button>
        </div>
      )}

      {/* Highlights active notes drawer */}
      {activeHighlightId && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] sm:w-[480px] bg-white dark:bg-stone-900 border border-amber-200 dark:border-stone-800 rounded-3xl p-5 shadow-2xl z-50 animate-fadeIn font-sans">
          <div className="flex justify-between items-center mb-3">
            <h4 className="text-xs font-bold text-stone-500 uppercase flex items-center gap-1">
              🖊 Update Highlight Annotation
            </h4>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  onDeleteHighlight(activeHighlightId);
                  setActiveHighlightId(null);
                }}
                className="p-1 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20"
                title="Delete Highlight"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setActiveHighlightId(null)}
                className="p-1 rounded-lg hover:bg-stone-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="text-xs italic text-stone-600 dark:text-stone-300 line-clamp-2 pl-3 border-l-2 border-stone-300 mb-4 bg-stone-50 dark:bg-stone-950 py-1.5 rounded-r-lg">
            "{highlights.find(h => h.id === activeHighlightId)?.text}"
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add your reading thoughts, key takeaway or thoughts..."
              value={noteInputValue}
              onChange={(e) => setNoteInputValue(e.target.value)}
              className="flex-1 bg-stone-50 dark:bg-stone-950 text-xs text-stone-800 dark:text-stone-100 border border-stone-200 dark:border-stone-850 px-3 py-2 rounded-xl focus:outline-hidden focus:border-amber-500"
            />
            <button
              onClick={handleUpdateNote}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-xl flex items-center gap-1 shadow-sm"
            >
              <Check className="w-3.5 h-3.5" /> Save Note
            </button>
          </div>
        </div>
      )}

      {/* Dictionary interactive modal card */}
      {dictionaryWord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-xs font-sans">
          <div className="bg-white dark:bg-stone-900 border border-amber-200/80 dark:border-stone-800 rounded-3xl p-6 shadow-2xl max-w-sm w-full relative animate-popIn">
            <button
              onClick={() => setDictionaryWord(null)}
              className="absolute top-4 right-4 p-1 rounded-xl hover:bg-purple-900/40 text-purple-400 dark:text-purple-300"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-pink-400 text-xs font-serif italic">Vocabulary Assist</span>
            </div>
            <h4 className="font-serif font-black text-2xl text-white leading-tight">
              {dictionaryWord.word}
            </h4>
            <div className="text-xs text-purple-300 font-mono mb-4">{dictionaryWord.pron}</div>
            <p className="text-sm text-purple-200 leading-relaxed bg-[#18092d]/80 p-4 rounded-2xl border border-purple-500/20">
              {dictionaryWord.def}
            </p>
            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setDictionaryWord(null)}
                className="px-4 py-2 bg-[#8338ec] hover:bg-[#904bf5] text-white text-xs font-bold rounded-xl cursor-pointer"
              >
                Done Looking
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Styled Preferences drawer panel (Style Configurator) */}
      {isStylePanelOpen && (
        <div className="fixed top-18 right-6 w-80 bg-[#160a28]/95 border border-purple-500/20 rounded-3xl p-5 shadow-2xl z-40 animate-fadeIn max-h-[80vh] overflow-y-auto text-xs text-purple-200 font-sans backdrop-blur-md shadow-pink-500/5">
          <div className="flex justify-between items-center mb-4 pb-2 border-b border-purple-500/10">
            <h4 className="font-serif font-bold text-sm text-pink-400 flex items-center gap-1">
              <span>⚙️ Style & Reader Config</span>
            </h4>
            <button
              onClick={() => setIsStylePanelOpen(false)}
              className="p-1 rounded-lg text-purple-300 hover:bg-[#25133d]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Theme selections */}
          <div className="space-y-4">
            <div>
              <span className="text-[10px] text-purple-300 uppercase tracking-widest block mb-2 font-semibold">
                Reader Color Theme
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'paper', label: 'Paper', bg: 'bg-[#0e051d]', border: 'border-purple-500/10', text: 'text-[#fae8ff]' },
                  { id: 'sepia', label: 'Sunset', bg: 'bg-[#210d1f]', border: 'border-pink-500/10', text: 'text-[#ffd3ff]' },
                  { id: 'slate', label: 'Slate', bg: 'bg-[#18082c]', border: 'border-cyan-500/10', text: 'text-[#e3c1ff]' },
                  { id: 'dusky', label: 'Dusky', bg: 'bg-[#0d041b]', border: 'border-purple-500/10', text: 'text-[#ffd6fb]' },
                  { id: 'forest', label: 'Lagoon', bg: 'bg-[#030e16]', border: 'border-teal-500/10', text: 'text-[#3affdf]' },
                  { id: 'midnight', label: 'Void', bg: 'bg-[#05010b]', border: 'border-sky-500/10', text: 'text-[#2ffff5]' }
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTheme(t.id as any)}
                    className={`p-2 py-2.5 rounded-xl border text-[10px] font-serif transition-all cursor-pointer ${t.bg} ${t.text} ${
                      theme === t.id
                        ? 'ring-2 ring-pink-500 font-bold border-pink-500 scale-102'
                        : `${t.border} hover:scale-102`
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Typography selection */}
            <div>
              <span className="text-[10px] text-purple-300 uppercase tracking-widest block mb-2 font-semibold">
                Font Family Pairings
              </span>
              <div className="space-y-1.5">
                {[
                  { id: 'font-lora', label: 'Lora — Elegant Editorial', preview: 'serif' },
                  { id: 'font-playfair', label: 'Playfair — Classic Display', preview: 'serif font-black' },
                  { id: 'font-source', label: 'Source Sans — Accessible UI', preview: 'sans' },
                  { id: 'font-noto', label: 'Noto Serif — Heavy Literary', preview: 'serif font-medium' },
                  { id: 'font-opendyslexic', label: 'OpenDyslexic — Inclusivity ♿', preview: 'serif font-bold text-pink-400' }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setFontFamily(f.id as any)}
                    className={`w-full px-3 py-2 rounded-xl text-left border cursor-pointer flex justify-between items-center transition-all ${
                      fontFamily === f.id
                        ? 'border-pink-500 bg-[#240e3d] text-white font-bold'
                        : 'border-purple-500/20 hover:bg-[#1a0c2e]'
                    }`}
                  >
                    <span className="font-sans text-[11px]">{f.label}</span>
                    <span className={`${f.preview} text-xs`}>Aa</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Font size adjustments */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[10px] text-purple-300 uppercase tracking-widest font-semibold">
                  Font Scale
                </span>
                <span className="text-[11px] text-pink-400 font-bold">{fontSize}px</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setFontSize(Math.max(13, fontSize - 1))}
                  className="px-2.5 py-1.5 bg-[#1a0b38] border border-purple-500/20 text-purple-200 rounded-lg hover:bg-[#25114d]"
                >
                  A-
                </button>
                <input
                  type="range"
                  min="13"
                  max="26"
                  value={fontSize}
                  onChange={(e) => setFontSize(parseInt(e.target.value))}
                  className="flex-1 accent-pink-500"
                />
                <button
                  onClick={() => setFontSize(Math.min(26, fontSize + 1))}
                  className="px-2.5 py-1.5 bg-[#1a0b38] border border-purple-500/20 text-purple-200 rounded-lg hover:bg-[#25114d]"
                >
                  A+
                </button>
              </div>
            </div>

            {/* Line Height adjuster */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[10px] text-purple-300 uppercase tracking-widest font-semibold">
                  Line Spacing
                </span>
                <span className="text-[11px] text-pink-400 font-bold">{lineHeight}x</span>
              </div>
              <input
                type="range"
                min="1.4"
                max="2.5"
                step="0.05"
                value={lineHeight}
                onChange={(e) => setLineHeight(parseFloat(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            {/* Margins Width adjuster */}
            <div>
              <span className="text-[10px] text-stone-400 uppercase tracking-widest block mb-1.5 font-semibold">
                Text Column Width
              </span>
              <div className="grid grid-cols-4 gap-1">
                {[
                  { id: 'narrow', val: '440px', label: 'Narrow' },
                  { id: 'compact', val: '540px', label: 'Compact' },
                  { id: 'cozy', val: '680px', label: 'Medium' },
                  { id: 'wide', val: '800px', label: 'Wide' }
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMarginWidth(m.id as any)}
                    className={`px-1 py-1.5 rounded-lg border text-[10px] text-center cursor-pointer transition-all ${
                      marginWidth === m.id
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 text-stone-900 dark:text-stone-50 font-bold'
                        : 'border-stone-200/50 dark:border-stone-800 hover:bg-stone-50'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Autoscrolling adjustments */}
            <div>
              <span className="text-[10px] text-stone-400 uppercase tracking-widest block mb-1.5 font-semibold">
                Hands-Free Autoscroll Speed
              </span>
              <div className="flex gap-1">
                {[
                  { speed: 0, label: 'Off' },
                  { speed: 1, label: 'Slow (1)' },
                  { speed: 2, label: 'Cozy (2)' },
                  { speed: 4, label: 'Steady (4)' },
                  { speed: 7, label: 'Fast (7)' }
                ].map((a) => (
                  <button
                    key={a.speed}
                    onClick={() => setAutoScrollSpeed(a.speed)}
                    className={`flex-1 px-1 py-1.5 rounded-lg border text-[10px] text-center cursor-pointer ${
                      autoScrollSpeed === a.speed
                        ? 'border-amber-500 bg-amber-50/50 dark:bg-amber-950/20 text-amber-600 dark:text-amber-400 font-bold'
                        : 'border-stone-200/50 dark:border-stone-800 hover:bg-stone-50'
                    }`}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
