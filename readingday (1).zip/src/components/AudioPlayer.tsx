import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Flame, CloudRain, ShieldCheck, Zap, Radio } from 'lucide-react';

export default function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState<Record<string, boolean>>({
    rain: false,
    fire: false,
    binaural: false,
    library: false,
  });
  const [volumes, setVolumes] = useState<Record<string, number>>({
    rain: 0.4,
    fire: 0.4,
    binaural: 0.3,
    library: 0.3,
  });

  const audioCtxRef = useRef<AudioContext | null>(null);
  
  // Audio Nodes storage
  const nodesRef = useRef<Record<string, {
    source: AudioScheduledSourceNode | AudioWorkletNode | OscillatorNode | ScriptProcessorNode | null;
    gain: GainNode | null;
  }>>({
    rain: { source: null, gain: null },
    fire: { source: null, gain: null },
    binaural: { source: null, gain: null },
    library: { source: null, gain: null },
  });

  const initAudioContext = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  // Noise generator (Pink noise is warmer and great for rain/library)
  const createPinkNoiseNode = (ctx: AudioContext) => {
    const bufferSize = 4096;
    const node = ctx.createScriptProcessor(bufferSize, 1, 1);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    
    node.onaudioprocess = (e) => {
      const output = e.outputBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        output[i] *= 0.11; // compensation
        b6 = white * 0.115926;
      }
    };
    return node;
  };

  // Generate Crackle Pops for firewood
  const startFireCrackle = (ctx: AudioContext, destination: AudioNode) => {
    const bufferSize = 4096;
    // ScriptProcessor to generate crackling clicks
    const node = ctx.createScriptProcessor(bufferSize, 1, 1);
    node.onaudioprocess = (e) => {
      const output = e.outputBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = 0;
        // Random clicks
        if (Math.random() < 0.0003) {
          output[i] = (Math.random() * 2 - 1) * 0.6;
        }
        // Crackling hum/rumble (filtered low frequency)
        if (Math.random() < 0.005) {
          output[i] += (Math.random() * 2 - 1) * 0.04;
        }
      }
    };

    // Filter crackle to make it crisp but deep
    const bandpass = ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.value = 1800;
    bandpass.Q.value = 4.0;

    node.connect(bandpass);
    bandpass.connect(destination);

    return node;
  };

  const toggleSound = (sound: string) => {
    initAudioContext();
    const ctx = audioCtxRef.current;
    if (!ctx) return;

    if (isPlaying[sound]) {
      // STOP
      if (nodesRef.current[sound].source) {
        try {
          (nodesRef.current[sound].source as any).disconnect();
          if (sound === 'binaural') {
            // binaural has multiple sub-nodes
            (nodesRef.current[sound].source as any).stop();
          }
        } catch (e) {}
        nodesRef.current[sound].source = null;
      }
      setIsPlaying(p => ({ ...p, [sound]: false }));
    } else {
      // START
      const gainNode = ctx.createGain();
      gainNode.gain.setValueAtTime(volumes[sound], ctx.currentTime);
      gainNode.connect(ctx.destination);
      nodesRef.current[sound].gain = gainNode;

      if (sound === 'rain') {
        const noise = createPinkNoiseNode(ctx);
        const lowpass = ctx.createBiquadFilter();
        lowpass.type = 'lowpass';
        lowpass.frequency.value = 700; // soft rain filter
        lowpass.connect(gainNode);
        noise.connect(lowpass);
        nodesRef.current[sound].source = noise as any;
      } 
      else if (sound === 'fire') {
        const noise = createPinkNoiseNode(ctx);
        const lpf = ctx.createBiquadFilter();
        lpf.type = 'lowpass';
        lpf.frequency.value = 250; // low wood rumble
        lpf.connect(gainNode);
        noise.connect(lpf);

        // Crisp crackles
        const crackleNode = startFireCrackle(ctx, gainNode);
        nodesRef.current[sound].source = crackleNode as any;
      } 
      else if (sound === 'binaural') {
        // Binaural beat uses two oscillators with frequency offset (e.g., 200Hz Left, 210Hz Right => 10Hz Alpha waves)
        const oscL = ctx.createOscillator();
        const oscR = ctx.createOscillator();
        const merger = ctx.createChannelMerger(2);

        oscL.type = 'sine';
        oscL.frequency.setValueAtTime(150, ctx.currentTime); // Deep focus frequency
        
        oscR.type = 'sine';
        oscR.frequency.setValueAtTime(160, ctx.currentTime); // 10Hz offset for alpha focus

        const pannerL = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
        const pannerR = ctx.createStereoPanner ? ctx.createStereoPanner() : null;

        if (pannerL && pannerR) {
          pannerL.pan.setValueAtTime(-1, ctx.currentTime);
          pannerR.pan.setValueAtTime(1, ctx.currentTime);
          oscL.connect(pannerL).connect(gainNode);
          oscR.connect(pannerR).connect(gainNode);
        } else {
          oscL.connect(merger, 0, 0);
          oscR.connect(merger, 0, 1);
          merger.connect(gainNode);
        }

        oscL.start();
        oscR.start();

        // Storing L oscillator as the primary source to stop later
        nodesRef.current[sound].source = {
          disconnect: () => {
            oscL.disconnect();
            oscR.disconnect();
            if (pannerL) pannerL.disconnect();
            if (pannerR) pannerR.disconnect();
          },
          stop: () => {
            oscL.stop();
            oscR.stop();
          }
        } as any;
      } 
      else if (sound === 'library') {
        const noise = createPinkNoiseNode(ctx);
        // Bandpass to sound like old walls/shuffling air
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 400;
        filter.Q.value = 0.5;
        
        filter.connect(gainNode);
        noise.connect(filter);
        nodesRef.current[sound].source = noise as any;
      }

      setIsPlaying(p => ({ ...p, [sound]: true }));
    }
  };

  const handleVolumeChange = (sound: string, value: number) => {
    setVolumes(v => ({ ...v, [sound]: value }));
    const gainNode = nodesRef.current[sound].gain;
    if (gainNode && audioCtxRef.current) {
      gainNode.gain.setValueAtTime(value, audioCtxRef.current.currentTime);
    }
  };

  useEffect(() => {
    return () => {
      // Cleanup all sound nodes on component unmount
      Object.keys(nodesRef.current).forEach(sound => {
        if (nodesRef.current[sound].source) {
          try {
            (nodesRef.current[sound].source as any).disconnect();
            (nodesRef.current[sound].source as any).stop();
          } catch (e) {}
        }
      });
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
      }
    };
  }, []);

  return (
    <div className="bg-[#18092d]/65 backdrop-blur-md border border-purple-500/20 rounded-2xl p-5 mb-6 shadow-lg shadow-purple-950/20">
      <h3 className="font-serif font-bold text-pink-400 text-lg mb-3 flex items-center gap-2">
        <Radio className="w-5 h-5 text-pink-500 animate-pulse" />
        Ambient Soundscape
      </h3>
      <p className="text-xs text-purple-300/80 mb-4 font-sans leading-relaxed">
        Natively synthesized auditory environments to trigger state-of-the-art flow, focus, and reading speed.
      </p>

      <div className="space-y-4 font-sans">
        {/* Autumn Rain */}
        <div className="flex items-center justify-between gap-3 bg-[#110524]/65 p-2.5 rounded-xl border border-purple-500/10">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => toggleSound('rain')}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                isPlaying.rain
                  ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25'
                  : 'bg-[#1a0b38] text-purple-300 hover:bg-[#230f4a]'
              }`}
            >
              <CloudRain className="w-4 h-4" />
            </button>
            <div>
              <div className="text-xs font-semibold text-purple-100">Autumn Rain</div>
              <div className="text-[10px] text-purple-400/60 font-mono">Warm rain rustle</div>
            </div>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volumes.rain}
            disabled={!isPlaying.rain}
            onChange={(e) => handleVolumeChange('rain', parseFloat(e.target.value))}
            className="w-24 h-1 rounded-lg bg-purple-950 accent-pink-500 disabled:opacity-30 cursor-pointer"
          />
        </div>

        {/* Campfire */}
        <div className="flex items-center justify-between gap-3 bg-[#110524]/65 p-2.5 rounded-xl border border-purple-500/10">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => toggleSound('fire')}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                isPlaying.fire
                  ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25'
                  : 'bg-[#1a0b38] text-purple-300 hover:bg-[#230f4a]'
              }`}
            >
              <Flame className="w-4 h-4" />
            </button>
            <div>
              <div className="text-xs font-semibold text-purple-100">Hearth Fire</div>
              <div className="text-[10px] text-purple-400/60 font-mono">Crisp crackling wood</div>
            </div>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volumes.fire}
            disabled={!isPlaying.fire}
            onChange={(e) => handleVolumeChange('fire', parseFloat(e.target.value))}
            className="w-24 h-1 rounded-lg bg-purple-950 accent-pink-500 disabled:opacity-30 cursor-pointer"
          />
        </div>

        {/* Alpha Beats */}
        <div className="flex items-center justify-between gap-3 bg-[#110524]/65 p-2.5 rounded-xl border border-purple-500/10">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => toggleSound('binaural')}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                isPlaying.binaural
                  ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25'
                  : 'bg-[#1a0b38] text-purple-300 hover:bg-[#230f4a]'
              }`}
            >
              <Zap className="w-4 h-4" />
            </button>
            <div>
              <div className="text-xs font-semibold text-purple-100">Binaural Alpha</div>
              <div className="text-[10px] text-purple-400/60 font-mono">10Hz alpha focus beat</div>
            </div>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volumes.binaural}
            disabled={!isPlaying.binaural}
            onChange={(e) => handleVolumeChange('binaural', parseFloat(e.target.value))}
            className="w-24 h-1 rounded-lg bg-purple-950 accent-pink-500 disabled:opacity-30 cursor-pointer"
          />
        </div>

        {/* Library Hum */}
        <div className="flex items-center justify-between gap-3 bg-[#110524]/65 p-2.5 rounded-xl border border-purple-500/10">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => toggleSound('library')}
              className={`p-2 rounded-lg transition-all cursor-pointer ${
                isPlaying.library
                  ? 'bg-gradient-to-tr from-pink-500 to-purple-600 text-white shadow-md shadow-pink-500/25'
                  : 'bg-[#1a0b38] text-purple-300 hover:bg-[#230f4a]'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
            </button>
            <div>
              <div className="text-xs font-semibold text-purple-100">Library Hum</div>
              <div className="text-[10px] text-purple-400/60 font-mono">Cozy air shuffling</div>
            </div>
          </div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volumes.library}
            disabled={!isPlaying.library}
            onChange={(e) => handleVolumeChange('library', parseFloat(e.target.value))}
            className="w-24 h-1 rounded-lg bg-purple-950 accent-pink-500 disabled:opacity-30 cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
}
