import React, { useState } from 'react';
import { Book } from '../types';
import { Search, Star, Clock, Sparkles, Filter, ChevronRight, HelpCircle } from 'lucide-react';

interface BookshelfProps {
  books: Book[];
  onSelectBook: (bookId: string) => void;
  savedPositions: Record<string, number>; // Book progress percentage map
}

export default function Bookshelf({ books, onSelectBook, savedPositions }: BookshelfProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('All');
  const [sortBy, setSortBy] = useState<'rating' | 'title' | 'author' | 'year'>('rating');

  // Genres gathered from database
  const allGenres = ['All', 'Fantasy', 'Sci-Fi', 'Classics', 'Gothic', 'Philosophy'];

  const filteredBooks = books
    .filter((book) => {
      const matchSearch =
        book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        book.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchGenre = selectedGenre === 'All' || book.genre.includes(selectedGenre);
      return matchSearch && matchGenre;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'title') return a.title.localeCompare(b.title);
      if (sortBy === 'author') return a.author.localeCompare(b.author);
      if (sortBy === 'year') return b.year.localeCompare(a.year);
      return 0;
    });

  // Group books into shelves of up to 4 books so they align nicely on physical shelf ledges
  const booksPerShelf = 4;
  const shelves: Book[][] = [];
  for (let i = 0; i < filteredBooks.length; i += booksPerShelf) {
    shelves.push(filteredBooks.slice(i, i + booksPerShelf));
  }

  return (
    <div className="w-full">
      {/* Decorative controls header card */}
      <div className="bg-[#18092d]/65 backdrop-blur-md border border-purple-500/20 rounded-3xl p-6 mb-8 shadow-lg shadow-purple-950/20">
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          
          {/* Search bar */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-purple-400/70 w-4.5 h-4.5" />
            <input
              type="text"
              placeholder="Search books, authors, words..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#110524] text-purple-100 rounded-2xl pl-10 pr-4 py-2.5 text-sm border border-purple-500/20 focus:border-[#f06292] focus:outline-hidden transition-all placeholder-purple-450"
            />
          </div>

          {/* Genre chips */}
          <div className="flex gap-1.5 flex-wrap justify-center">
            {allGenres.map((genre) => (
              <button
                key={genre}
                onClick={() => setSelectedGenre(genre)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-serif transition-colors cursor-pointer ${
                  selectedGenre === genre
                    ? 'bg-gradient-to-r from-pink-500 via-[#f06292] to-purple-600 text-white shadow-md font-bold'
                    : 'bg-[#120627] text-purple-300 border border-purple-500/10 hover:bg-[#1a0c36] hover:text-white'
                }`}
              >
                {genre === 'All' ? '✦ All Libraries' : genre}
              </button>
            ))}
          </div>

          {/* Sorting controls */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-purple-400 dark:text-purple-300 font-sans flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Sort by:
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#110524] text-purple-100 border border-purple-500/20 rounded-xl px-3 py-1.5 text-xs font-sans focus:outline-hidden focus:border-[#f06292] cursor-pointer"
            >
              <option value="rating">Rating ★</option>
              <option value="title">Title A-Z</option>
              <option value="author">Author</option>
              <option value="year">Publish Date</option>
            </select>
          </div>

        </div>
      </div>

      {/* Actual Tactile Bookshelves */}
      {shelves.length === 0 ? (
        <div className="text-center py-16 bg-[#16082b]/40 border border-dashed border-purple-550/20 rounded-3xl backdrop-blur-xs">
          <HelpCircle className="w-12 h-12 text-purple-400/30 mx-auto mb-3" />
          <h3 className="font-serif text-lg text-purple-300 font-bold">No books found</h3>
          <p className="text-xs text-purple-400/60 mt-1">Try resetting search filters or key terms.</p>
        </div>
      ) : (
        <div className="space-y-12">
          {shelves.map((shelf, sIdx) => (
            <div key={sIdx} className="relative pb-6">
              
              {/* Responsive columns inside shelf */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-8 gap-y-12 px-4 relative z-10">
                {shelf.map((book) => {
                  const progress = savedPositions[book.id] || 0;
                  return (
                    <div
                      key={book.id}
                      onClick={() => onSelectBook(book.id)}
                      className="group cursor-pointer flex flex-col items-center"
                    >
                      {/* Interactive 3D Book Cover Container */}
                      <div className="relative w-32 sm:w-36 aspect-[2/3] rounded-r-lg shadow-md group-hover:shadow-2xl transition-all duration-300 transform group-hover:-translate-y-3.5 group-hover:rotate-2 group-hover:scale-[1.05] overflow-visible perspective-1000">
                        {/* Realistic spine highlight overlay */}
                        <div className="absolute top-0 left-0 bottom-0 w-2.5 bg-gradient-to-r from-black/35 via-white/10 to-transparent z-20 rounded-l-xs" />
                        
                        {/* Book background & emoji design */}
                        <div
                          style={{ background: book.coverBg }}
                          className="absolute inset-0 rounded-r-md rounded-l-xs flex flex-col justify-between p-3 select-none text-white z-10"
                        >
                          <div className="flex justify-between items-start">
                            <span className="text-[10px] tracking-wider uppercase font-semibold text-white/70">
                              {book.year}
                            </span>
                            <span className="text-xs">📖</span>
                          </div>

                          <div className="my-auto text-center flex flex-col items-center">
                            <span className="text-4xl sm:text-5xl my-2 filter drop-shadow-md transform group-hover:scale-115 transition-all duration-500">
                              {book.coverEmoji}
                            </span>
                            <h4 className="font-serif font-black text-xs sm:text-[13px] leading-tight text-white line-clamp-2 mt-1 drop-shadow-sm px-1 font-bold">
                              {book.title}
                            </h4>
                          </div>

                          <div className="text-center">
                            <p className="text-[9px] text-[#2ffff5] font-mono truncate font-bold">
                              {book.author}
                            </p>
                          </div>
                        </div>

                        {/* Paper edge page thickness simulator representing a realistic book edge */}
                        <div className="absolute top-0 right-0 bottom-0 w-1.5 bg-[#fcf9f2] dark:bg-zinc-800 border-l border-r border-zinc-200 dark:border-zinc-700 z-10 rounded-r-xs transform origin-right translate-x-[4px] scale-y-[0.98]" />

                        {/* Speed badge or completed badge */}
                        {progress > 0 && (
                          <div className="absolute -top-2.5 -right-2.5 bg-gradient-to-r from-[#ff6b6b] to-[#f06292] text-white text-[10px] font-bold px-2 py-0.5 rounded-full z-30 shadow-md animate-bounce">
                            {progress === 100 ? 'Completed' : `${progress}%`}
                          </div>
                        )}
                      </div>

                      {/* Tactile detail list metadata below book cover */}
                      <div className="text-center mt-3 max-w-[150px]">
                        <h5 className="font-serif font-bold text-sm text-purple-100 group-hover:text-pink-400 transition-colors line-clamp-1">
                          {book.title}
                        </h5>
                        <p className="text-[11px] text-purple-300/60 font-sans truncate">
                          by {book.author}
                        </p>
                        
                        {/* Quality Rating stars & estimated time */}
                        <div className="flex items-center justify-center gap-1 mt-1">
                          <span className="flex items-center text-pink-400 font-semibold text-[11px] gap-0.5">
                            <Star className="w-3 h-3 fill-pink-500 text-pink-500" /> {book.rating}
                          </span>
                          <span className="text-purple-650">•</span>
                          <span className="text-[10px] text-purple-300/60 font-mono flex items-center gap-0.5">
                            <Clock className="w-2.5 h-2.5" /> {book.estimatedReadTime}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Skeuomorphic Cybernetic Glowing Purple/Pink ledges shelf structure with absolute shadow, bevel */}
              <div className="absolute bottom-0 left-0 right-0 h-4 bg-gradient-to-r from-[#ff6b6b] via-[#bc4fcd] to-purple-900 rounded-lg shadow-lg border-b border-purple-950 z-0 opacity-90">
                <div className="w-full h-1.5 bg-black/40 rounded-t-lg" />
              </div>
              <div className="absolute bottom-[-10px] left-2 right-2 h-2.5 bg-black/55 rounded-b-md filter blur-[3px] z-0" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
