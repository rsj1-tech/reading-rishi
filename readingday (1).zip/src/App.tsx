import React, { useState, useEffect } from 'react';
import { Book, Highlight, SavedPosition, UserStats } from './types';
import { BOOKS_DATABASE } from './data/books';
import Bookshelf from './components/Bookshelf';
import Reader from './components/Reader';
import Dashboard from './components/Dashboard';
import {
  BookOpen,
  Sparkles,
  Flame,
  Award,
  BookmarkCheck,
  Type,
  Sun,
  Moon,
  Github,
  Compass,
  Scroll,
  HelpCircle
} from 'lucide-react';

export default function App() {
  // Loaded databases
  const [books] = useState<Book[]>(BOOKS_DATABASE);

  // Central Application States
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  
  // Highlights, Progress and Achievements state loading with LocalStorage persistence
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [savedPositions, setSavedPositions] = useState<Record<string, SavedPosition>>({});
  const [userStats, setUserStats] = useState<UserStats>({
    streak: 14,
    lastReadDate: null,
    dailyGoalMinutes: 30,
    todayMinutesRead: 0,
    totalChaptersCompleted: 4,
  });

  const [mainTheme, setMainTheme] = useState<'light' | 'dark'>('light');

  // Load persisted states on mount
  useEffect(() => {
    try {
      const savedHl = localStorage.getItem('rd_highlights');
      if (savedHl) setHighlights(JSON.parse(savedHl));

      const savedPos = localStorage.getItem('rd_positions');
      if (savedPos) setSavedPositions(JSON.parse(savedPos));

      const savedS = localStorage.getItem('rd_stats');
      if (savedS) {
        setUserStats(JSON.parse(savedS));
      } else {
        // First run stats
        const initialStats: UserStats = {
          streak: 14,
          lastReadDate: new Date().toLocaleDateString(),
          dailyGoalMinutes: 30,
          todayMinutesRead: 12,
          totalChaptersCompleted: 4,
        };
        setUserStats(initialStats);
        localStorage.setItem('rd_stats', JSON.stringify(initialStats));
      }

      const pTheme = localStorage.getItem('rd_main_theme');
      if (pTheme === 'dark') {
        setMainTheme('dark');
        document.documentElement.classList.add('dark');
      } else {
        setMainTheme('light');
        document.documentElement.classList.remove('dark');
      }
    } catch (e) {
      console.warn("Storage reading fallback initiated.");
    }
  }, []);

  // Sync state functions
  const handleAddHighlight = (newHl: Highlight) => {
    const updated = [newHl, ...highlights];
    setHighlights(updated);
    localStorage.setItem('rd_highlights', JSON.stringify(updated));
  };

  const handleDeleteHighlight = (hlId: string) => {
    const filtered = highlights.filter(h => h.id !== hlId);
    setHighlights(filtered);
    localStorage.setItem('rd_highlights', JSON.stringify(filtered));
  };

  const handleUpdateHighlightNote = (hlId: string, note: string) => {
    const updated = highlights.map(h => h.id === hlId ? { ...h, note } : h);
    setHighlights(updated);
    localStorage.setItem('rd_highlights', JSON.stringify(updated));
  };

  const handleSavePosition = (position: SavedPosition) => {
    const updated = {
      ...savedPositions,
      [position.bookId]: position,
    };
    setSavedPositions(updated);
    localStorage.setItem('rd_positions', JSON.stringify(updated));

    // Gamification hook: Increment read statistics
    const statsUpdate = {
      ...userStats,
      todayMinutesRead: userStats.todayMinutesRead + 2, // abstract read minutes logging
    };
    setUserStats(statsUpdate);
    localStorage.setItem('rd_stats', JSON.stringify(statsUpdate));
  };

  const handleUpdateStats = (newStats: UserStats) => {
    setUserStats(newStats);
    localStorage.setItem('rd_stats', JSON.stringify(newStats));
  };

  const toggleMainTheme = () => {
    if (mainTheme === 'light') {
      setMainTheme('dark');
      document.documentElement.classList.add('dark');
      localStorage.setItem('rd_main_theme', 'dark');
    } else {
      setMainTheme('light');
      document.documentElement.classList.remove('dark');
      localStorage.setItem('rd_main_theme', 'light');
    }
  };

  const handleJumpToQuote = (bookId: string, chapterId: string) => {
    // Open reader specifically targeting the matching book
    setActiveBookId(bookId);
  };

  // Maps savedPositions percentage for the Bookshelf display
  const getProgressPercentages = () => {
    const map: Record<string, number> = {};
    Object.keys(savedPositions).forEach(bId => {
      map[bId] = savedPositions[bId].scrollOffsetPct;
    });
    return map;
  };

  const activeBook = books.find(b => b.id === activeBookId);

  return (
    <div className="min-h-screen bg-[#0e051d] text-purple-100 transition-colors duration-300 select-none pb-12 font-serif relative overflow-x-hidden">
      
      {/* Absolute floating glowing cosmic cloud background shapes for Parallax / Decorator feel */}
      <div className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-purple-600/15 rounded-full filter blur-[140px] pointer-events-none select-none animate-pulse duration-[8000ms]" />
      <div className="absolute top-[30%] -right-40 w-[600px] h-[600px] bg-pink-500/15 rounded-full filter blur-[150px] pointer-events-none select-none" />
      <div className="absolute bottom-[10%] left-[10%] w-[500px] h-[500px] bg-indigo-500/10 rounded-full filter blur-[120px] pointer-events-none select-none" />

      {/* Primary header navbar - Glassmorphic luxury */}
      <nav className="sticky top-0 z-40 bg-[#160a28]/75 border-b border-purple-500/20 backdrop-blur-md px-6 py-4 flex items-center justify-between shadow-lg shadow-purple-950/20">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 bg-gradient-to-tr from-pink-500 via-purple-600 to-cyan-500 rounded-2xl flex items-center justify-center shadow-lg shadow-pink-500/20 text-white font-bold text-lg select-none hover:scale-105 transition-all">
            📖
          </div>
          <div>
            <h1 className="text-xl font-serif font-black tracking-tight bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-300 bg-clip-text text-transparent leading-none">
              ReadingDay
            </h1>
            <span className="text-[10px] text-purple-300 uppercase tracking-widest font-sans font-black">
              Your infinite literary universe
            </span>
          </div>
        </div>

        {/* Theme and Streaks status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-gradient-to-r from-purple-500/20 to-pink-500/20 px-3.5 py-1.5 rounded-full text-xs font-sans font-bold border border-pink-500/30">
            <Flame className="w-4.5 h-4.5 text-pink-500 animate-pulse fill-pink-500/20" />
            <span className="bg-gradient-to-r from-pink-400 to-purple-300 bg-clip-text text-transparent">{userStats.streak} Day Run!</span>
          </div>
        </div>
      </nav>

      {/* Immense Celestial Parallax Library Landing Header Banner layout */}
      <header className="relative py-16 sm:py-24 px-6 border-b border-purple-500/10 overflow-hidden bg-gradient-to-b from-[#180b2f] via-[#0f061f] to-[#0e051d] text-center font-sans">
        
        {/* Animated Flying Vector Books via lightweight pure CSS animation details */}
        <div className="absolute top-10 left-[12%] text-4xl opacity-30 select-none animate-bounce duration-1000 transform hover:scale-125 transition-transform cursor-help">📔</div>
        <div className="absolute bottom-12 right-[10%] text-5xl opacity-30 select-none animate-bounce duration-1500 transform hover:scale-125 transition-transform cursor-help">📜</div>
        <div className="absolute top-20 right-[15%] text-4xl opacity-30 select-none animate-bounce duration-2000 transform hover:scale-125 transition-transform cursor-help">🧭</div>
        <div className="absolute bottom-8 left-[15%] text-4xl opacity-30 select-none animate-pulse duration-1000 transform hover:scale-125 transition-transform cursor-help">🔮</div>

        <div className="max-w-3xl mx-auto relative z-10 space-y-4">
          <div className="inline-flex items-center gap-1.5 bg-[#ff6b6b]/10 text-[#f06292] border border-[#f06292]/30 text-[11px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full shadow-inner">
            <Sparkles className="w-3.5 h-3.5 animate-spin" /> Virtual Bookshelves Live • Vibrant Theme
          </div>
          
          <h2 className="text-3xl sm:text-6xl font-serif font-black tracking-tight text-white leading-tight">
            Every page is an<br />
            <span className="italic bg-gradient-to-r from-pink-400 via-[#f06292] to-cyan-400 bg-clip-text text-transparent font-medium">immersion</span> into new horizons
          </h2>
          
          <p className="text-xs sm:text-sm text-purple-200/70 max-w-lg mx-auto leading-relaxed">
            Natively engineered speecher, customizable speed and layout variables, color matrices, vocabulary indexes, Web Audio noise integration, and persistent gamification elements.
          </p>

          {/* Quick Stats Grid representing book items count and achievements */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 max-w-2xl mx-auto">
            <div className="bg-[#1f113a]/60 p-4 rounded-2xl border border-purple-500/20 backdrop-blur-md shadow-lg">
              <span className="block text-2xl font-serif font-black text-[#ff6b6b] leading-none">
                {books.length} Full
              </span>
              <span className="text-[10px] text-purple-300 uppercase tracking-wider font-semibold">
                Classic Chapters
              </span>
            </div>
            
            <div className="bg-[#1f113a]/60 p-4 rounded-2xl border border-purple-500/20 backdrop-blur-md shadow-lg">
              <span className="block text-2xl font-serif font-black text-[#f06292] leading-none">
                {highlights.length} Items
              </span>
              <span className="text-[10px] text-purple-300 uppercase tracking-wider font-semibold">
                Captured Quotes
              </span>
            </div>

            <div className="bg-[#1f113a]/60 p-4 rounded-2xl border border-purple-500/20 backdrop-blur-md shadow-lg">
              <span className="block text-2xl font-serif font-black text-cyan-400 leading-none">
                {userStats.totalChaptersCompleted} Ch.
              </span>
              <span className="text-[10px] text-purple-300 uppercase tracking-wider font-semibold">
                Finished So Far
              </span>
            </div>

            <div className="bg-[#1f113a]/60 p-4 rounded-2xl border border-purple-500/20 backdrop-blur-md shadow-lg">
              <span className="block text-2xl font-serif font-black text-[#af52ff] leading-none">
                Infinite
              </span>
              <span className="text-[10px] text-purple-300 uppercase tracking-wider font-semibold">
                Immersive Flow
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main dual-view segment split */}
      <main className="max-w-7xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Bookshelf layout spanning 8 columns on large viewports */}
          <section className="lg:col-span-8 space-y-6">
            <h3 className="font-serif font-black text-2xl mb-1 text-pink-400 flex items-center gap-2">
              📚 Tactical Responsive Bookshelf
            </h3>
            <p className="text-xs text-purple-300/80 font-sans leading-relaxed mb-6">
              Double-tap/Hover a volume to start reading. Your reading depth progress indicator is automatically preserved vertically!
            </p>
            
            <Bookshelf
              books={books}
              onSelectBook={(id) => setActiveBookId(id)}
              savedPositions={getProgressPercentages()}
            />
          </section>

          {/* Sidebar Panel containing streak challenges, audio modifiers, and notebook metrics */}
          <aside className="lg:col-span-4 space-y-8">
            <Dashboard
              books={books}
              userStats={userStats}
              onUpdateStats={handleUpdateStats}
              highlights={highlights}
              onDeleteHighlight={handleDeleteHighlight}
              onJumpToQuote={handleJumpToQuote}
            />
          </aside>

        </div>
      </main>

      {/* Elegant minimalist footer */}
      <footer className="max-w-4xl mx-auto text-center border-t border-purple-500/10 pt-8 mt-12 font-sans text-xs text-purple-400/60 space-y-2">
        <p className="font-serif font-bold text-pink-405">
          ReadingDay © 2026 — Beautifully Designed Dynamic Library System.
        </p>
        <p className="text-[10px] text-purple-350 leading-relaxed">
          Natively compiled under TypeScript state handlers. Full classic chapters from Alice's Adventures in Wonderland, The Time Machine, The Metamorphosis, and The Picture of Dorian Gray.
        </p>
      </footer>

      {/* Active Reading Overlay view portal segment */}
      {activeBook && (
        <Reader
          book={activeBook}
          onClose={() => setActiveBookId(null)}
          savedPosition={savedPositions[activeBook.id]}
          onSavePosition={handleSavePosition}
          highlights={highlights}
          onAddHighlight={handleAddHighlight}
          onDeleteHighlight={handleDeleteHighlight}
          onUpdateHighlightNote={handleUpdateHighlightNote}
        />
      )}

    </div>
  );
}
